#!/usr/bin/env bash
# usage: bash run_demo.sh <full NetFlow-v3 CSV> <models folder>
set -e
SRC="$1"; PKG="${2:-models}"
[ -f demo_flows.csv ] || python make_demo_csv.py --src "$SRC" --out demo_flows.csv --per-class 2 --benign 8
python engine.py --pkg "$PKG" --csv demo_flows.csv --db ids.db --calibrate-windows 8 --auto-feedback 0.2 --sleep 3 --reset &
ENGINE=$!
trap "kill $ENGINE 2>/dev/null" EXIT
streamlit run dashboard.py -- --db ids.db
