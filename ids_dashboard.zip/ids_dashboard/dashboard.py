"""IDS analyst dashboard (Streamlit).  Run:  streamlit run dashboard.py -- --db ids.db

Reads what engine.py writes, and writes the analyst's decisions back (confirm / false positive / relabel,
review-queue labels, retrain request, pause). The engine uses those labels for Champion/Challenger adaptation.
"""
import json
import sys
import sqlite3

import networkx as nx
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import db as dbm

DB = sys.argv[sys.argv.index("--db") + 1] if "--db" in sys.argv else "ids.db"

st.set_page_config(page_title="Hybrid GNN-Transformer IDS", layout="wide")

# fixed colour per attack family (categorical slots in fixed order, never cycled); severity uses the status palette
FAMILY_COLOR = {"DDoS": "#2a78d6", "DoS": "#eb6834", "BruteForce": "#1baf7a", "Web": "#eda100",
                "Bot": "#e87ba4", "Infiltration": "#008300", "Unknown": "#6250d6", "Other": "#e34948"}
FAMILY_ORDER = list(FAMILY_COLOR)
SEV_COLOR = {"critical": "#d03b3b", "high": "#ec835a", "medium": "#fab219", "none": "#9aa5b1"}
SEV_ICON = {"critical": "🔴 critical", "high": "🟠 high", "medium": "🟡 medium", "none": "none"}


def family(name):
    n = str(name).lower()
    if n == "benign": return "Benign"
    if "unknown" in n: return "Unknown"
    if "ddos" in n: return "DDoS"
    if "dos" in n: return "DoS"
    if any(s in n for s in ["xss", "sql", "web"]): return "Web"
    if "brute" in n: return "BruteForce"
    if "bot" in n: return "Bot"
    if "infil" in n: return "Infiltration"
    return "Other"


@st.cache_resource
def con():
    return dbm.connect(DB)


def q(sql, params=()):
    return pd.read_sql(sql, con(), params=params)


def layout(fig, h=320):
    fig.update_layout(height=h, margin=dict(l=10, r=10, t=40, b=10), legend=dict(orientation="h", y=1.02, yanchor="bottom", x=0),
                      plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)")
    fig.update_xaxes(showgrid=False); fig.update_yaxes(gridcolor="rgba(128,128,128,0.15)", zeroline=False)
    return fig


# ------------------------------------------------------------------ sidebar
st.sidebar.title("Hybrid GNN + Transformer IDS")
page = st.sidebar.radio("View", ["Overview", "Alerts", "Host graph", "Review queue", "Model & adaptation"])
demo = st.sidebar.toggle("Demo mode (show ground truth)", value=True)
auto = st.sidebar.toggle("Auto-refresh", value=True)
every = st.sidebar.slider("Refresh every (s)", 2, 30, 5)
st.sidebar.divider()
status = dbm.get_control(con(), "status", "waiting for engine")
paused = dbm.get_control(con(), "paused") == "1"
st.sidebar.caption(f"Engine: **{'paused' if paused else status}** · model v{dbm.get_control(con(), 'model_version', '?')}")
c1, c2 = st.sidebar.columns(2)
if c1.button("Resume" if paused else "Pause", use_container_width=True):
    dbm.set_control(con(), "paused", "0" if paused else "1"); st.rerun()
if c2.button("Retrain now", use_container_width=True, help="Ask the engine to train a challenger at its next check"):
    dbm.set_control(con(), "retrain_requested", "1"); st.sidebar.success("Requested")
CLASSES = json.loads(dbm.get_control(con(), "classes", "[]"))


def refreshing(fn):
    return st.fragment(run_every=every if auto else None)(fn)


# ------------------------------------------------------------------ Overview
@refreshing
def overview():
    w = q("SELECT * FROM windows ORDER BY id")
    if w.empty:
        st.info("No windows yet — start engine.py."); return
    w["label"] = pd.to_datetime(w.start).dt.strftime("%m-%d %H:%M")      # windows can be far apart: category axis
    total_w = dbm.get_control(con(), "total_windows")
    a_cnt = q("SELECT severity, COUNT(*) n FROM alerts GROUP BY severity").set_index("severity")["n"]
    far = w["est_far"].dropna()
    k = st.columns(6)
    k[0].metric("Windows analysed", f"{len(w)}" + (f" / {total_w}" if total_w else ""))
    k[1].metric("Flows analysed", f"{int(w.main_flows.sum()):,}")
    k[2].metric("Alerts", f"{int(w.alerts.sum()):,}", help="all alerts; the strongest 400 per window are stored for review")
    k[3].metric("New-attack alerts", f"{int(w.unknown_alerts.sum()):,}", help="flagged only by the energy / max-softmax scores")
    k[4].metric("Est. false-alarm rate", f"{far.iloc[-1]:.2%}" if len(far) else "—", help="from analyst-labelled random samples (last 10 windows); target 1%")
    k[5].metric("Latency / window", f"{w.latency_ms.tail(20).mean():.0f} ms",
                help=f"{w.main_flows.sum() / (w.latency_ms.sum() / 1000):,.0f} flows/s on this machine")

    rows = []
    for _, r in w.iterrows():
        for cls, n in json.loads(r.alerts_by_class or "{}").items():
            rows.append({"window": r.label, "family": family(cls), "alerts": n})
    left, right = st.columns([2.2, 1])
    with left:
        st.subheader("Alerts per 2-minute window")
        if rows:
            d = pd.DataFrame(rows).groupby(["window", "family"], as_index=False)["alerts"].sum()
            fig = go.Figure()
            for f in [f for f in FAMILY_ORDER if f in set(d.family)]:
                s = d[d.family == f]
                fig.add_bar(x=s.window, y=s.alerts, name=f, marker_color=FAMILY_COLOR[f], marker_line_width=0,
                            hovertemplate=f"<b>{f}</b><br>%{{x}}<br>%{{y:,}} alerts<extra></extra>")
            if demo and w.true_attacks.notna().any():
                fig.add_scatter(x=w.label, y=w.true_attacks, name="true attack flows (ground truth)", mode="markers",
                                marker=dict(symbol="line-ew-open", size=14, color="#52514e", line=dict(width=2)),
                                hovertemplate="%{y:,} true attack flows<extra></extra>")
            fig.update_layout(barmode="stack", bargap=0.25)
            fig.update_xaxes(type="category", categoryorder="array", categoryarray=list(w.label), tickangle=-45, nticks=12)
            st.plotly_chart(layout(fig, 340), use_container_width=True)
        else:
            st.caption("No alerts yet.")
    with right:
        st.subheader("Alerts by severity")
        sev = [s for s in ["critical", "high", "medium"] if s in a_cnt.index]
        if sev:
            fig = go.Figure(go.Bar(x=[int(a_cnt[s]) for s in sev], y=[SEV_ICON[s] for s in sev], orientation="h",
                                   marker_color=[SEV_COLOR[s] for s in sev], text=[f"{int(a_cnt[s]):,}" for s in sev],
                                   textposition="outside", cliponaxis=False, hovertemplate="%{y}: %{x:,}<extra></extra>"))
            fig.update_yaxes(autorange="reversed"); fig.update_xaxes(range=[0, max(int(a_cnt[s]) for s in sev) * 1.25])
            st.plotly_chart(layout(fig, 180), use_container_width=True)
        st.subheader("Top attacking hosts")
        top = q("SELECT src AS host, COUNT(*) AS alerts, GROUP_CONCAT(DISTINCT pred) AS types FROM alerts "
                "GROUP BY src ORDER BY alerts DESC LIMIT 8")
        st.dataframe(top, hide_index=True, use_container_width=True)

    if len(far):
        st.subheader("Estimated false-alarm rate (analyst random samples)")
        fig = go.Figure(go.Scatter(x=w.label, y=w.est_far, mode="lines+markers", line=dict(width=2, color="#2a78d6"),
                                   marker=dict(size=8), name="estimated FAR", hovertemplate="%{x}<br>FAR %{y:.2%}<extra></extra>"))
        fig.add_hline(y=0.01, line_dash="dash", line_color="#9aa5b1", annotation_text="target 1%")
        fig.update_yaxes(tickformat=".1%", rangemode="tozero"); fig.update_xaxes(type="category", tickangle=-45, nticks=12)
        st.plotly_chart(layout(fig, 220), use_container_width=True)


# ------------------------------------------------------------------ Alerts
def explanation_view(a):
    e = json.loads(a.explanation) if isinstance(a.explanation, str) else None
    if not e or "error" in e:
        st.caption("Explanations are computed for the strongest alert of each type in every window. "
                   "Pick an alert marked ✓ in the 'explained' column to see one."); return
    st.markdown("**Why the model raised this alert** — Integrated Gradients through GNN + Transformer")
    tf = pd.DataFrame(e["top_features"]).iloc[::-1]
    fig = go.Figure(go.Bar(x=tf.attribution, y=tf.feature, orientation="h",
                           marker_color=["#2a78d6" if v > 0 else "#9aa5b1" for v in tf.attribution],
                           customdata=tf.raw_value, hovertemplate="%{y}<br>value %{customdata:,.0f}<br>push %{x:+.3f}<extra></extra>"))
    fig.update_layout(title="Features of this flow (blue = pushes towards the alert)")
    st.plotly_chart(layout(fig, 260), use_container_width=True)
    sh = e["share"]
    s1, s2, s3 = st.columns(3)
    s1.metric("From this flow", f"{sh['this flow']:.0%}")
    s2.metric("From the host's recent flows", f"{sh['host history']:.0%}", help="Transformer: earlier flows of the same source host")
    s3.metric("From other hosts (graph)", f"{sh['graph neighbours']:.0%}", help="GNN: flows of other hosts in the same window")
    st.markdown("**Earlier flows that mattered most**")
    st.dataframe(pd.DataFrame(e["context_flows"]).round(3), hide_index=True, use_container_width=True)


def alerts_page():
    st.subheader("Alerts")
    f1, f2, f3, f4 = st.columns(4)
    sev = f1.multiselect("Severity", ["critical", "high", "medium"], default=["critical", "high", "medium"])
    stat = f2.multiselect("Status", ["new", "confirmed", "false_positive"], default=["new", "confirmed", "false_positive"])
    host = f3.text_input("Host contains")
    only_exp = f4.toggle("Only explained alerts")
    sql = "SELECT * FROM alerts WHERE severity IN ({}) AND status IN ({})".format(
        ",".join("?" * len(sev)) or "''", ",".join("?" * len(stat)) or "''")
    params = list(sev) + list(stat)
    if host:
        sql += " AND (src LIKE ? OR dst LIKE ?)"; params += [f"%{host}%"] * 2
    if only_exp:
        sql += " AND explanation IS NOT NULL"
    a = q(sql + " ORDER BY id DESC LIMIT 2000", params)
    if a.empty:
        st.info("No alerts match."); return
    view = pd.DataFrame({"id": a.id, "time": a.ts.str.slice(0, 19), "severity": a.severity.map(SEV_ICON), "type": a.pred,
                         "src": a.src, "dst": a.dst, "dport": a.dport, "confidence": a.confidence.round(3),
                         "explained": np.where(a.explanation.notna(), "✓", ""), "status": a.status})
    if demo:
        view["ground truth"] = a.true_label
    sel = st.dataframe(view, hide_index=True, use_container_width=True, height=330, on_select="rerun", selection_mode="single-row")
    rows = sel.selection.rows if sel and sel.selection else []
    if not rows:
        st.caption("Select an alert to investigate it."); return
    al = a.iloc[rows[0]]
    st.divider()
    h1, h2 = st.columns([2, 1])
    with h1:
        st.markdown(f"### {al.pred}  ·  {SEV_ICON.get(al.severity, al.severity)}")
        st.markdown(f"`{al.src}:{al.sport}` → `{al.dst}:{al.dport}` · protocol {al.proto} · {al.ts[:19]}")
        m = st.columns(4)
        m[0].metric("Confidence", f"{al.confidence:.1%}")
        m[1].metric("Attack score", f"{al.attack_score:.3f}")
        m[2].metric("New-attack flag", "yes" if al.unknown else "no")
        m[3].metric("Model version", f"v{al.model_version}")
        explanation_view(al)
    with h2:
        st.markdown("**Analyst decision**")
        st.caption(f"Current status: **{al.status}**" + (f" · label: {al.analyst_label}" if isinstance(al.analyst_label, str) else ""))
        if demo:
            st.caption(f"Ground truth: **{al.true_label}**")
        if st.button("✓ Confirm attack", use_container_width=True):
            con().execute("UPDATE alerts SET status='confirmed', analyst_label=? WHERE id=?",
                          (al.pred if al.pred in CLASSES else al.analyst_label, int(al.id))); con().commit(); st.rerun()
        if st.button("✗ False positive (Benign)", use_container_width=True):
            con().execute("UPDATE alerts SET status='false_positive', analyst_label='Benign' WHERE id=?", (int(al.id),)); con().commit(); st.rerun()
        new = st.selectbox("Relabel as", [c for c in CLASSES if c != "Benign"], index=None, placeholder="choose the real attack type")
        if new and st.button("Save label", use_container_width=True):
            con().execute("UPDATE alerts SET status='confirmed', analyst_label=? WHERE id=?", (new, int(al.id))); con().commit(); st.rerun()
        st.caption("Labels feed the Champion/Challenger retraining.")


# ------------------------------------------------------------------ Host graph
def graph_page():
    w = q("SELECT id, start, alerts, main_flows, hosts FROM windows ORDER BY id DESC")
    if w.empty:
        st.info("No windows yet."); return
    pick = st.selectbox("Window", w.id, format_func=lambda i: f"{w.set_index('id').start[i]}  ·  "
                        f"{w.set_index('id').alerts[i]:,} alerts / {w.set_index('id').main_flows[i]:,} flows")
    edges = pd.DataFrame(json.loads(q("SELECT graph_json FROM windows WHERE id=?", (int(pick),)).graph_json[0]))
    if edges.empty:
        st.info("Empty window."); return
    G = nx.DiGraph()
    for _, e in edges.iterrows():
        G.add_edge(e.src, e.dst, flows=e.flows, alerts=e.alerts)
    pos = nx.spring_layout(G, seed=1, k=1.2 / np.sqrt(max(G.number_of_nodes(), 1)))
    fig = go.Figure()
    for alerted, color, name in [(False, "rgba(154,165,177,0.45)", "normal flows"), (True, "#d03b3b", "flows with alerts")]:
        xs, ys = [], []
        for u, v, d in G.edges(data=True):
            if (d["alerts"] > 0) == alerted:
                xs += [pos[u][0], pos[v][0], None]; ys += [pos[u][1], pos[v][1], None]
        fig.add_scatter(x=xs, y=ys, mode="lines", line=dict(width=2 if alerted else 1, color=color), name=name, hoverinfo="skip")
    deg = dict(G.degree()); hot = {n for u, v, d in G.edges(data=True) if d["alerts"] > 0 for n in (u, v)}
    for involved, color, name in [(False, "#2a78d6", "hosts"), (True, "#d03b3b", "hosts in alerted flows")]:
        nodes = [n for n in G.nodes() if (n in hot) == involved]
        if nodes:
            fig.add_scatter(x=[pos[n][0] for n in nodes], y=[pos[n][1] for n in nodes], mode="markers", name=name,
                            marker=dict(size=[8 + 2 * np.sqrt(deg[n]) for n in nodes], color=color, line=dict(width=2, color="white")),
                            text=[f"{n}<br>{deg[n]} connections" for n in nodes], hovertemplate="%{text}<extra></extra>")
    fig.update_xaxes(visible=False); fig.update_yaxes(visible=False)
    st.markdown("**Host communication graph** — node = host / IP, edge = flows between them (the graph the GNN sees)")
    st.plotly_chart(layout(fig, 560), use_container_width=True)
    st.dataframe(edges.sort_values(["alerts", "flows"], ascending=False).head(30), hide_index=True, use_container_width=True)


# ------------------------------------------------------------------ Review queue
def review_page():
    st.subheader("Review queue — random flows to label")
    st.caption("A random sample from every window. Labelling it gives an unbiased estimate of false alarms and missed "
               "attacks, and the labels train the next challenger model.")
    r = q("SELECT id, window, ts, src, dst, pred, alerted, attack_score, true_label, analyst_label FROM reviews "
          "WHERE analyst_label IS NULL ORDER BY id DESC LIMIT 200")
    done = q("SELECT COUNT(*) n, SUM(alerted) a FROM reviews WHERE analyst_label IS NOT NULL").iloc[0]
    st.metric("Labelled so far", f"{int(done.n or 0):,}")
    if r.empty:
        st.success("Queue is empty."); return
    ed = r.assign(alerted=r.alerted.astype(bool), label=None, ts=r.ts.str.slice(0, 19))
    cols = ["id", "ts", "src", "dst", "pred", "alerted", "attack_score"] + (["true_label"] if demo else []) + ["label"]
    out = st.data_editor(ed[cols], hide_index=True, use_container_width=True, height=420, disabled=cols[:-1],
                         column_config={"label": st.column_config.SelectboxColumn("your label", options=CLASSES)})
    b1, b2 = st.columns(2)
    if b1.button("Save labels", type="primary"):
        for _, x in out.dropna(subset=["label"]).iterrows():
            con().execute("UPDATE reviews SET analyst_label=? WHERE id=?", (x.label, int(x.id)))
        con().commit(); st.rerun()
    if demo and b2.button("Demo: accept ground truth for all"):
        con().execute("UPDATE reviews SET analyst_label=true_label WHERE analyst_label IS NULL AND true_label IS NOT NULL")
        con().commit(); st.rerun()


# ------------------------------------------------------------------ Model & adaptation
@refreshing
def model_page():
    st.subheader("Model & adaptation (Champion / Challenger)")
    ev = q("SELECT * FROM model_events ORDER BY id")
    thr = json.loads(dbm.get_control(con(), "thresholds", "{}") or "{}")
    fb = q("SELECT (SELECT COUNT(*) FROM alerts WHERE analyst_label IS NOT NULL) a, (SELECT COUNT(*) FROM reviews WHERE analyst_label IS NOT NULL) r").iloc[0]
    k = st.columns(4)
    k[0].metric("Live model", f"v{dbm.get_control(con(), 'model_version', '?')}")
    k[1].metric("Challengers promoted", int((ev.event == "challenger promoted").sum()) if len(ev) else 0)
    k[2].metric("Challengers rejected", int((ev.event == "challenger rejected").sum()) if len(ev) else 0)
    k[3].metric("Labelled feedback", f"{int(fb.a) + int(fb.r):,}")
    st.caption("A challenger is fine-tuned on analyst labels and only replaces the live model if, on held-out labels, it keeps "
               "false alarms ≤ 1% (or ≤ the current model), detects at least as many attacks, and is at least as accurate.")
    st.markdown("**Alert rule** — attack score " + (f"> {thr.get('attack', 0):.4f}" if thr else "") +
                (" **OR** energy / max-softmax above calibrated thresholds (new-attack detection)" if thr.get("calibrated") else
                 " (combined new-attack rule not calibrated — run the engine with --calibrate-windows)"))
    if len(ev):
        show = ev[["time", "window", "event", "n_feedback", "champion_far", "challenger_far", "champion_dr", "challenger_dr",
                   "champion_acc", "challenger_acc", "version", "note"]]
        st.dataframe(show.round(4), hide_index=True, use_container_width=True)
        c = ev[ev.event.str.startswith("challenger")].copy()
        if len(c):
            c["check"] = [f"check {i + 1} · window {w_}" for i, w_ in enumerate(c.window)]
            fig = go.Figure()
            fig.add_scatter(x=c.check, y=c.champion_acc, name="live model (held-out labels)", mode="lines+markers",
                            line=dict(width=2, color="#9aa5b1"), marker=dict(size=8))
            fig.add_scatter(x=c.check, y=c.challenger_acc, name="challenger", mode="lines+markers",
                            line=dict(width=2, color="#2a78d6"), marker=dict(size=8))
            fig.update_layout(title="Accuracy on held-out analyst labels"); fig.update_yaxes(tickformat=".0%"); fig.update_xaxes(type="category")
            st.plotly_chart(layout(fig, 260), use_container_width=True)


{"Overview": overview, "Alerts": alerts_page, "Host graph": graph_page, "Review queue": review_page,
 "Model & adaptation": model_page}[page]()
