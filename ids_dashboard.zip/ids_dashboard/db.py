"""SQLite store shared by the engine (writer) and the dashboard (reader + analyst feedback)."""
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS windows (
    id INTEGER PRIMARY KEY, start TEXT, flows INTEGER, main_flows INTEGER, hosts INTEGER,
    alerts INTEGER, unknown_alerts INTEGER, alerts_by_class TEXT, true_attacks INTEGER,
    latency_ms REAL, model_version INTEGER, est_far REAL, graph_json TEXT, processed_at TEXT);
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, window INTEGER, ts TEXT, src TEXT, dst TEXT, sport INTEGER, dport INTEGER,
    proto INTEGER, pred TEXT, family TEXT, confidence REAL, attack_score REAL, energy REAL, msp REAL, unknown INTEGER,
    severity TEXT, true_label TEXT, explanation TEXT, status TEXT DEFAULT 'new', analyst_label TEXT, model_version INTEGER);
CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT, window INTEGER, ts TEXT, src TEXT, dst TEXT, pred TEXT, attack_score REAL,
    alerted INTEGER, true_label TEXT, analyst_label TEXT);
CREATE TABLE IF NOT EXISTS model_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT, window INTEGER, event TEXT, n_feedback INTEGER,
    champion_far REAL, challenger_far REAL, champion_dr REAL, challenger_dr REAL,
    champion_acc REAL, challenger_acc REAL, accepted INTEGER, version INTEGER, note TEXT);
CREATE TABLE IF NOT EXISTS control (key TEXT PRIMARY KEY, value TEXT);
CREATE INDEX IF NOT EXISTS ix_alerts_window ON alerts(window);
CREATE INDEX IF NOT EXISTS ix_reviews_window ON reviews(window);
"""


def connect(path):
    con = sqlite3.connect(path, timeout=30, check_same_thread=False)
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    return con


def get_control(con, key, default=None):
    r = con.execute("SELECT value FROM control WHERE key=?", (key,)).fetchone()
    return r[0] if r else default


def set_control(con, key, value):
    con.execute("INSERT INTO control(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))
    con.commit()
