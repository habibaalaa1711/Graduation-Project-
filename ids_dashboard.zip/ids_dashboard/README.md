# Live IDS Dashboard — Hybrid Host-Graph GNN + Temporal Transformer

Steps 15–16 of the project flowchart: the final v5 model running on a stream of flows, with an analyst dashboard and
Champion / Challenger adaptation.

```
NetFlow-v3 flows ──► engine.py ──► ids.db (SQLite) ◄──► dashboard.py (Streamlit)
                    2-min windows      alerts, explanations,      analyst: confirm / false positive /
                    + 1-min warm-up    host graphs, reviews,      relabel, review queue, retrain,
                    GATv2 ► Transformer model versions            pause
                    combined rule
                    Champion/Challenger ◄──────── analyst labels
```

## Files

| file | what it does |
|---|---|
| `ids_core.py` | loads the package; builds the window graph (node = host, edge = flow) and the per-host sequences exactly like training; scores; Integrated-Gradients explanations |
| `engine.py` | replays a CSV window by window, writes everything to SQLite, runs Champion/Challenger |
| `dashboard.py` | Streamlit dashboard (5 views) |
| `make_demo_csv.py` | cuts a demo replay file (a few windows per attack + normal windows) out of the full dataset |
| `db.py` | database schema |

## Setup (once)

```bash
pip install -r requirements.txt
```
Put the **official v5 package** in a folder, e.g. `models/`:
`models/final_model_package.pt` and `models/final_preprocessing.joblib`.
A GPU is optional — on a laptop CPU a 2-minute window takes from well under a second to a few seconds.

## Run the demo

```bash
# 1) demo replay file from the full dataset (takes a few minutes: it scans the whole CSV twice)
python make_demo_csv.py --src NF-CICIDS2018-v3.csv --out demo_flows.csv --per-class 2 --benign 8

# 2) engine (terminal 1)
python engine.py --pkg models --csv demo_flows.csv --db ids.db --calibrate-windows 8 --auto-feedback 0.2 --sleep 3 --reset

# 3) dashboard (terminal 2) -> opens http://localhost:8501
streamlit run dashboard.py -- --db ids.db
```
Or simply `bash run_demo.sh NF-CICIDS2018-v3.csv models` (does all three).

### Engine options
| option | meaning |
|---|---|
| `--calibrate-windows N` | **onboarding**: uses the labels of the first N windows to set the 3 thresholds of the combined rule (attack score OR energy OR max-softmax) at 1% false alarms → `thresholds.json`. Without it, only the attack score is used. |
| `--auto-feedback F` | demo: simulates an analyst (labels all review samples + a fraction F of alerts with the CSV ground truth). Leave it out to label everything yourself in the dashboard. |
| `--sleep S` | seconds between windows, for a "live" feel in a presentation |
| `--explain-per-window N`, `--ig-steps S` | explanations per window (strongest alert of each type) and their precision; lower them on a slow CPU |
| `--reset` | empty the database first |

## Dashboard views

1. **Overview** — flows analysed, alerts, new-attack alerts, estimated false-alarm rate, latency; alerts per window by attack family
   (with ground truth in demo mode); severity; top attacking hosts.
2. **Alerts** — filter and pick an alert: why the model raised it (top features of the flow, share coming from the flow itself /
   the host's earlier flows / other hosts in the graph, the earlier flows that mattered) and the analyst decision
   (confirm, false positive, relabel).
3. **Host graph** — the communication graph of any window as the GNN sees it; hosts and flows involved in alerts in red.
4. **Review queue** — random flows from every window to label: gives an unbiased false-alarm / missed-attack estimate and
   training labels.
5. **Model & adaptation** — live model version, every Champion/Challenger check (held-out FAR, detection rate, accuracy,
   promoted or rejected, and why), the alert rule; "Retrain now" in the sidebar asks the engine for a check.

## Champion / Challenger (why a fine-tuned model is not always deployed)
v6 showed that fine-tuning on analyst feedback raised detection on the Web-attack day from 62% to 95% but raised false alarms
to 10% on the Infiltration day. So the engine fine-tunes a **challenger** on 70% of the analyst labels and promotes it only if,
on the other 30%, it keeps false alarms ≤ 1% (or ≤ the live model), detects at least as many attacks and is at least as accurate.
Otherwise the live model stays. Every decision is logged and shown in the dashboard.

## Real traffic (next step: the lab)
`engine.py` takes any CSV with the NetFlow-v3 columns. When the flow extractor is chosen (nProbe or an open tool
producing the same features), its output is replayed or tailed the same way. A different network needs **onboarding**:
label ~20 minutes of its traffic (`--calibrate-windows` + review queue) — the cross-dataset test (UNSW) showed a model
never transfers zero-shot, but a few labelled windows restore Benign/Attack detection.
