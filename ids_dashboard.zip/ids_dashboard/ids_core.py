"""Core of the live IDS: loads the v5 final package and scores one time window of flows.

The model classes and the preprocessing are IDENTICAL to the training notebooks (v4/v5), so the saved
weights load without changes and the window context (graph + per-host sequences) is built exactly as in training.
"""
import json
import math
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import GATv2Conv

SRC_IP, DST_IP, SRC_PORT, DST_PORT = "IPV4_SRC_ADDR", "IPV4_DST_ADDR", "L4_SRC_PORT", "L4_DST_PORT"
T_START, PROTO, LABEL = "FLOW_START_MILLISECONDS", "PROTOCOL", "Attack"

SEVERITY = {"Benign": "none", "DDoS": "high", "DoS": "high", "Web": "high", "BruteForce": "medium",
            "Bot": "critical", "Infiltration": "critical", "Unknown": "high"}


def family(name):
    n = str(name).lower()
    if n == "benign": return "Benign"
    if "unknown" in n: return "Unknown"
    if "ddos" in n: return "DDoS"
    if "dos" in n: return "DoS"
    if any(s in n for s in ["xss", "sql", "web"]): return "Web"
    if "brute" in n: return "BruteForce"
    if "bot" in n: return "Bot"
    if "infil" in n: return "Infiltration"
    return "Other"


# ----------------------------------------------------------------- models (same as v5) ---
class GATEncoder(nn.Module):
    def __init__(self, node_in, edge_in, hp):
        super().__init__()
        H, Hd, E, D = hp["GNN_HIDDEN"], hp["GNN_HEADS"], hp["EMB_DIM"], hp["DROPOUT"]
        self.gat1 = GATv2Conv(node_in, H, heads=Hd, concat=True, edge_dim=edge_in, dropout=D)
        self.ln1 = nn.LayerNorm(H * Hd)
        self.gat2 = GATv2Conv(H * Hd, H, heads=1, concat=False, edge_dim=edge_in, dropout=D)
        self.ln2 = nn.LayerNorm(H)
        self.drop = nn.Dropout(D)
        self.edge_proj = nn.Sequential(nn.Linear(2 * H + edge_in, E), nn.LayerNorm(E), nn.ReLU(), nn.Dropout(D))

    def node_embed(self, g):
        x = self.drop(F.elu(self.ln1(self.gat1(g.x, g.edge_index, g.edge_attr))))
        return F.elu(self.ln2(self.gat2(x, g.edge_index, g.edge_attr)))

    def flow_embed(self, z, g, loc):
        return self.edge_proj(torch.cat([z[g.flow_src[loc]], z[g.flow_dst[loc]], g.flow_attr[loc]], 1))


class GATv2Clf(nn.Module):
    def __init__(self, node_in, edge_in, n_cls, hp):
        super().__init__()
        self.gnn = GATEncoder(node_in, edge_in, hp)
        self.head = nn.Sequential(nn.Dropout(hp["DROPOUT"]), nn.Linear(hp["EMB_DIM"], n_cls))


class TemporalTransformer(nn.Module):
    def __init__(self, tok_in, k, hp):
        super().__init__()
        Dm = hp["D_MODEL"]
        self.inp = nn.Linear(tok_in + 1, Dm)
        self.pos = nn.Parameter(torch.randn(1, k, Dm) * 0.02)
        layer = nn.TransformerEncoderLayer(Dm, hp["N_HEADS"], hp["FF_DIM"], hp["DROPOUT"], activation="gelu",
                                           batch_first=True, norm_first=True)
        self.enc = nn.TransformerEncoder(layer, hp["N_LAYERS"], enable_nested_tensor=False)
        self.norm = nn.LayerNorm(Dm)

    def forward(self, tok, dt, pad):
        h = self.inp(torch.cat([tok, dt.unsqueeze(-1)], -1)) + self.pos[:, -tok.size(1):]
        return self.norm(self.enc(h, src_key_padding_mask=pad)[:, -1])


class SeqClf(nn.Module):
    """Two-stage second stage: Transformer over the GNN flow embeddings of a host's recent flows."""
    def __init__(self, tok_in, k, n_cls, hp):
        super().__init__()
        self.source = "emb"
        self.temporal = TemporalTransformer(tok_in, k, hp)
        self.head = nn.Sequential(nn.Dropout(hp["DROPOUT"]), nn.Linear(hp["D_MODEL"], n_cls))

    def from_tokens(self, tok, dt, pad):
        tok = tok.masked_fill(pad.unsqueeze(-1), 0.0)
        return self.head(self.temporal(tok, dt, pad))


# ----------------------------------------------------------------- window preprocessing ---
def node_stats(src, dst):
    hosts, inv = np.unique(np.concatenate([src, dst]), return_inverse=True)
    s, d = inv[:len(src)], inv[len(src):]
    n = len(hosts)
    out_d, in_d = np.bincount(s, minlength=n), np.bincount(d, minlength=n)
    u_out = pd.Series(d).groupby(s).nunique().reindex(range(n), fill_value=0).values
    u_in = pd.Series(s).groupby(d).nunique().reindex(range(n), fill_value=0).values
    x = np.log1p(np.stack([out_d, in_d, out_d + in_d, u_out, u_in], 1).astype(np.float32))
    return x, s, d, hosts


def build_seq(ts_seconds, src, k):
    """Row i = previous k-1 flows of the same source host in this window, then flow i (-1 = padding)."""
    n = len(src)
    g = pd.factorize(src)[0]
    order = np.lexsort((np.arange(n), ts_seconds, g))
    gs = g[order]
    pos = np.arange(n) - np.searchsorted(gs, gs, side="left")
    seq = np.full((n, k), -1, dtype=np.int64)
    r = np.arange(n)
    for j in range(k):
        lag = k - 1 - j
        ok = pos >= lag
        seq[order[ok], j] = order[r[ok] - lag]
    valid = seq >= 0
    dt = np.zeros((n, k), np.float32)
    dt[valid] = np.log1p(np.maximum(np.broadcast_to(ts_seconds[:, None], (n, k))[valid] - ts_seconds[seq[valid]], 0))
    return seq, dt


# ----------------------------------------------------------------- the detector ---
class Detector:
    def __init__(self, pkg_dir, device=None, thresholds_path=None):
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        pkg_dir = Path(pkg_dir)
        self.pkg = torch.load(pkg_dir / "final_model_package.pt", map_location=self.device, weights_only=False)
        self.pre = joblib.load(pkg_dir / "final_preprocessing.joblib")
        p = self.pkg
        self.classes = list(p["classes"]); self.benign = int(p["benign_id"])
        self.features = list(p["features"]); self.log1p = bool(p["log1p"])
        self.k = int(p["dims"]["k"]); self.hp = p["hparams"]
        self.T = float(p.get("temperature", 1.0))
        self.window_min = int(p.get("window", {}).get("WINDOW_MIN", 2))
        self.margin_sec = int(p.get("window", {}).get("MARGIN_SEC", 60))
        self.gat = GATv2Clf(p["dims"]["node_in"], p["dims"]["edge_in"], len(self.classes), self.hp).to(self.device)
        self.gat.load_state_dict(p["gatv2_state"]); self.gat.eval()
        self.two = SeqClf(self.hp["EMB_DIM"], self.k, len(self.classes), self.hp).to(self.device)
        self.two.load_state_dict(p["two_stage_state"]); self.two.eval()
        self.version = 1
        # thresholds of the combined rule (attack OR energy OR max-softmax). Without calibration: attack score only.
        self.thr = {"attack": float(p["attack_threshold"]), "energy": math.inf, "msp": math.inf, "calibrated": False}
        if thresholds_path and Path(thresholds_path).exists():
            self.thr.update(json.load(open(thresholds_path)))

    # ---------- features ----------
    def _features(self, df):
        X = df[self.features].apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)
        if self.log1p:
            X = np.sign(X) * np.log1p(np.abs(X))
        X = self.pre["scaler"].transform(self.pre["imputer"].transform(X))
        return np.clip(X, -10, 10).astype(np.float32)

    def prepare_window(self, frame):
        """frame: all flows of one window incl. the warm-up minute, sorted by time, with column _main."""
        dev = self.device
        X = torch.tensor(self._features(frame), device=dev)
        x, s, d, hosts = node_stats(frame[SRC_IP].astype(str).values, frame[DST_IP].astype(str).values)
        s_t = torch.tensor(s, dtype=torch.long, device=dev); d_t = torch.tensor(d, dtype=torch.long, device=dev)
        g = dict(x=torch.tensor(self.pre["node_scaler"].transform(x).astype(np.float32), device=dev),
                 s=s_t, d=d_t, hosts=hosts)
        ts = pd.to_numeric(frame[T_START], errors="coerce").values / 1000.0
        seq, dt = build_seq(ts, frame[SRC_IP].astype(str).values, self.k)
        return {"X": X, "g": g, "seq": torch.tensor(seq, device=dev), "dt": torch.tensor(dt, device=dev),
                "main": np.where(frame["_main"].values)[0]}

    def _graph(self, W, X):
        s, d = W["g"]["s"], W["g"]["d"]
        return Data(x=W["g"]["x"], edge_index=torch.stack([torch.cat([s, d]), torch.cat([d, s])]),
                    edge_attr=torch.cat([X, X]), flow_src=s, flow_dst=d, flow_attr=X)

    def embeddings(self, W, X=None):
        X = W["X"] if X is None else X
        g = self._graph(W, X)
        return self.gat.gnn.flow_embed(self.gat.gnn.node_embed(g), g, torch.arange(X.shape[0], device=self.device))

    def tokens(self, W, emb, rows):
        seq = W["seq"][rows]; pad = seq < 0
        return emb[seq.clamp(min=0)], W["dt"][rows], pad

    def logits(self, W, rows, X=None, model=None):
        model = model or self.two
        emb = self.embeddings(W, X)
        tok, dt, pad = self.tokens(W, emb, rows)
        return model.from_tokens(tok, dt, pad)

    # ---------- scoring ----------
    @torch.no_grad()
    def score_window(self, W, bs=4096):
        rows = torch.tensor(W["main"], device=self.device)
        emb = self.embeddings(W)
        out = []
        for b in range(0, len(rows), bs):
            r = rows[b:b + bs]
            tok, dt, pad = self.tokens(W, emb, r)
            out.append(self.two.from_tokens(tok, dt, pad))
        lg = torch.cat(out) / self.T if out else torch.zeros(0, len(self.classes), device=self.device)
        p = torch.softmax(lg, 1)
        res = {"prob": p.cpu().numpy(), "attack": (1 - p[:, self.benign]).cpu().numpy(),
               "energy": (-self.T * torch.logsumexp(lg, 1)).cpu().numpy(), "msp": (-p.max(1).values).cpu().numpy()}
        res["pred"] = res["prob"].argmax(1)
        fire_attack = res["attack"] > self.thr["attack"]
        fire_unknown = (res["energy"] > self.thr["energy"]) | (res["msp"] > self.thr["msp"])
        res["alert"] = fire_attack | fire_unknown
        res["unknown"] = fire_unknown & ~fire_attack            # flagged only by the new-attack scores
        res["emb"] = emb
        return res

    def label_of(self, pred, unknown):
        return "Unknown attack" if unknown else self.classes[pred]

    # ---------- explanation (Integrated Gradients through GNN + Transformer) ----------
    def explain(self, W, frame, row, cls, steps=8):
        dev = self.device
        r = torch.tensor([row], device=dev)
        X = W["X"]; base = torch.zeros_like(X)
        tot = torch.zeros_like(X)
        for a in (np.arange(steps) + 0.5) / steps:
            Xa = (base + a * (X - base)).requires_grad_(True)
            lg = self.logits(W, r, Xa)[0, cls]
            tot += torch.autograd.grad(lg, Xa)[0]
        attr = ((X - base) * tot / steps).detach()
        per_flow = attr.sum(1).cpu().numpy(); own = attr[row].cpu().numpy()
        ab = attr.abs().sum(1).cpu().numpy(); total = ab.sum() + 1e-12
        hist = W["seq"][row].cpu().numpy(); hist = hist[(hist >= 0) & (hist != row)]
        rest = np.ones(len(ab), bool); rest[row] = False; rest[hist] = False
        top_f = np.argsort(-np.abs(own))[:6]
        ctx = [q for q in np.argsort(-np.abs(per_flow)) if q != row][:5]
        t_row = frame["_ts"].iloc[row]
        return {
            "top_features": [{"feature": self.features[f], "attribution": float(own[f]),
                              "raw_value": float(pd.to_numeric(frame[self.features[f]].iloc[row], errors="coerce"))} for f in top_f],
            "share": {"this flow": float(ab[row] / total), "host history": float(ab[hist].sum() / total),
                      "graph neighbours": float(ab[rest].sum() / total)},
            "context_flows": [{"src": str(frame[SRC_IP].iloc[q]), "dst": str(frame[DST_IP].iloc[q]),
                               "seconds_before": float((t_row - frame["_ts"].iloc[q]).total_seconds()),
                               "relation": "host history" if q in hist else "graph neighbour",
                               "attribution": float(per_flow[q])} for q in ctx]}
