"""Cut a demo replay file out of the full NF-CSE-CIC-IDS2018-v3 CSV (or any NetFlow-v3 CSV).

Picks a few 2-minute windows per attack class + some attack-free windows (spread over the days), keeps ALL flows
of those windows plus the 1-minute warm-up before each, and writes them sorted by time — ready for engine.py.

    python make_demo_csv.py --src NF-CICIDS2018-v3.csv --out demo_flows.csv --per-class 2 --benign 8
"""
import argparse
import json
from collections import defaultdict

import numpy as np
import pandas as pd

T, L = "FLOW_START_MILLISECONDS", "Attack"


def main(a):
    wms, margin = a.window_min * 60_000, a.margin_sec * 1000
    cnt = defaultdict(int)
    for ch in pd.read_csv(a.src, usecols=[T, L], chunksize=1_000_000, low_memory=False):
        b = pd.to_numeric(ch[T], errors="coerce") // wms
        for (bb, c), n in pd.DataFrame({"b": b, "c": ch[L].astype(str).str.strip()}).dropna().value_counts().items():
            cnt[(int(bb), c)] += int(n)
    W = pd.Series(cnt).unstack(fill_value=0)
    total = W.sum(axis=1); attack = W.drop(columns=["Benign"], errors="ignore").sum(1)
    day = pd.Series(pd.to_datetime(W.index.values * wms, unit="ms").strftime("%Y-%m-%d"), index=W.index)
    rng = np.random.default_rng(a.seed); sel = {}
    for c in [c for c in W.columns if c != "Benign"]:
        cand = W.index[(W[c] >= 20) & (total <= a.max_window_flows) & ~W.index.isin(list(sel))]
        if len(cand) == 0:
            cand = W.index[(W[c] > 0) & ~W.index.isin(list(sel))]
            cand = cand[np.argsort(total.loc[cand].values)][:max(a.per_class, 1)]
        for b in rng.choice(cand, min(a.per_class, len(cand)), replace=False):
            sel[int(b)] = c
    ben = W.index[(attack == 0) & (total <= a.max_window_flows) & ~W.index.isin(list(sel))]
    by_day = {d: list(rng.permutation(g.index.values)) for d, g in day.loc[ben].groupby(day.loc[ben])}
    picked = []
    while len(picked) < a.benign and any(by_day.values()):
        for d in by_day:
            if by_day[d] and len(picked) < a.benign:
                picked.append(int(by_day[d].pop()))
    for b in picked:
        sel[b] = "Benign"
    S = set(sel)
    parts = []
    for ch in pd.read_csv(a.src, chunksize=1_000_000, low_memory=False):
        t = pd.to_numeric(ch[T], errors="coerce"); b = t // wms; nb = b + 1
        keep = b.isin(S) | (nb.isin(S) & (t >= nb * wms - margin))
        if keep.any():
            parts.append(ch[keep])
    out = pd.concat(parts).drop_duplicates().sort_values(T, kind="mergesort")
    out.to_csv(a.out, index=False)
    json.dump(sorted(int(b) for b in S), open(a.out + ".windows.json", "w"))   # engine replays exactly these windows
    print(f"{len(S)} windows -> {len(out):,} flows written to {a.out}")
    print(pd.Series(sel).value_counts().to_string())


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True); ap.add_argument("--out", default="demo_flows.csv")
    ap.add_argument("--per-class", type=int, default=2); ap.add_argument("--benign", type=int, default=8)
    ap.add_argument("--max-window-flows", type=int, default=30_000)
    ap.add_argument("--window-min", type=int, default=2); ap.add_argument("--margin-sec", type=int, default=60)
    ap.add_argument("--seed", type=int, default=42)
    main(ap.parse_args())
