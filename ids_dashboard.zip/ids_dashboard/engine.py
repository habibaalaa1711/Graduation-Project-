"""Live IDS engine: replays NetFlow-v3 flows window by window (2 min + 1 min warm-up), scores them with the final
Two-stage model, writes alerts / explanations / host graphs to SQLite, and adapts with analyst feedback
using a Champion / Challenger policy.

    python engine.py --pkg models --csv demo_flows.csv --db ids.db --calibrate-windows 6 --auto-feedback 0.2

--calibrate-windows N : "onboarding" — use the labels of the first N windows to set the thresholds of the combined
                        rule (attack score OR energy OR max-softmax) at 1% false alarms. Saved to thresholds.json.
--auto-feedback F     : demo mode — simulates an analyst: labels every review sample and a fraction F of the alerts
                        with the ground-truth label from the CSV.
"""
import argparse
import copy
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

import db as dbm
from ids_core import Detector, SEVERITY, family, SRC_IP, DST_IP, SRC_PORT, DST_PORT, T_START, PROTO, LABEL

TARGET_FAR = 0.01
MAX_ALERTS_STORED = 400        # per window (all alerts are counted; the strongest are stored for the analyst)
REVIEW_PER_WINDOW = 25         # random flows per window for the analyst review queue (unbiased FAR estimate)
EXPLAIN_PER_WINDOW = 6         # alerts per window explained with Integrated Gradients
ADAPT_EVERY = 5                # windows between Champion/Challenger checks
MIN_FEEDBACK = 150             # labelled flows needed before a challenger is trained
FT_EPOCHS, FT_LR = 3, 1e-4


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_flows(path, features):
    use = list(dict.fromkeys([T_START, "FLOW_END_MILLISECONDS", SRC_IP, DST_IP, SRC_PORT, DST_PORT, PROTO, LABEL] + features))
    df = pd.read_csv(path, usecols=lambda c: str(c).strip() in use, low_memory=False)
    df.columns = [str(c).strip() for c in df.columns]
    df["_t"] = pd.to_numeric(df[T_START], errors="coerce")
    df = df.dropna(subset=["_t", SRC_IP, DST_IP]).sort_values("_t", kind="mergesort").reset_index(drop=True)
    df["_ts"] = pd.to_datetime(df["_t"], unit="ms", utc=True)
    df[SRC_IP] = df[SRC_IP].astype(str); df[DST_IP] = df[DST_IP].astype(str)
    if LABEL in df.columns:
        df[LABEL] = df[LABEL].astype(str).str.strip()
    return df


def windows_of(df, wms, margin_ms, only=None):
    t = df["_t"].values
    for b in np.unique((t // wms).astype(np.int64)):
        if only is not None and int(b) not in only:
            continue
        lo = np.searchsorted(t, b * wms - margin_ms, "left"); mid = np.searchsorted(t, b * wms, "left")
        hi = np.searchsorted(t, (b + 1) * wms, "left")
        if hi > mid:
            frame = df.iloc[lo:hi].copy()
            frame["_main"] = np.arange(lo, hi) >= mid
            yield int(b), frame


def graph_snapshot(frame, alert_rows, max_edges=250):
    flag = np.zeros(len(frame), bool); flag[alert_rows] = True
    m = frame.assign(_alert=flag)[frame["_main"].values]
    e = m.groupby([SRC_IP, DST_IP]).agg(flows=("_t", "size"), alerts=("_alert", "sum")).reset_index()
    e = pd.concat([e[e.alerts > 0].nlargest(max_edges // 2, "alerts"), e[e.alerts == 0].nlargest(max_edges // 2, "flows")])
    return json.dumps([{"src": r[SRC_IP], "dst": r[DST_IP], "flows": int(r.flows), "alerts": int(r.alerts)} for _, r in e.iterrows()])


def union_thresholds(scores, far):
    """Common tail fraction f for the three scores so that their UNION fires on `far` of the Benign flows."""
    def thr(f):
        return {k: float(np.quantile(scores[k], 1 - f)) for k in ["attack", "energy", "msp"]}
    def fires(th):
        return (scores["attack"] > th["attack"]) | (scores["energy"] > th["energy"]) | (scores["msp"] > th["msp"])
    lo, hi = far / 3, far
    for _ in range(30):
        mid = (lo + hi) / 2
        if fires(thr(mid)).mean() > far: hi = mid
        else: lo = mid
    return {**thr(lo), "calibrated": True}


class Engine:
    def __init__(self, args):
        self.a = args
        self.det = Detector(args.pkg, thresholds_path=args.thresholds)
        self.con = dbm.connect(args.db)
        if args.reset:
            for t in ["windows", "alerts", "reviews", "model_events", "control"]:
                self.con.execute(f"DELETE FROM {t}")
            self.con.commit()
        self.tokens = {}                     # feedback key -> (tok, dt, pad) kept for Champion/Challenger training
        self.versions_dir = Path(args.db).with_suffix("").parent / "model_versions"
        self.versions_dir.mkdir(exist_ok=True)
        self.rng = np.random.default_rng(0)
        dbm.set_control(self.con, "classes", json.dumps(self.det.classes))
        dbm.set_control(self.con, "thresholds", json.dumps(self.det.thr))
        dbm.set_control(self.con, "model_version", self.det.version)
        self.con.execute("INSERT INTO model_events(time, window, event, version, accepted, note) VALUES(?,?,?,?,?,?)",
                         (now(), -1, "deployed", self.det.version, 1, "final package from v5"))
        self.con.commit()

    # ------------------------------------------------------------------ calibration (onboarding)
    def calibrate(self, frames):
        ben = {"attack": [], "energy": [], "msp": []}
        for _, frame in frames:
            W = self.det.prepare_window(frame)
            res = self.det.score_window(W)
            y = frame[LABEL].values[W["main"]]
            for k in ben:
                ben[k].append(res[k][y == "Benign"])
        sc = {k: np.concatenate(v) for k, v in ben.items()}
        if len(sc["attack"]) < 200:
            print("Calibration skipped: fewer than 200 Benign flows in the onboarding windows.")
            return
        self.det.thr = union_thresholds(sc, TARGET_FAR)
        json.dump(self.det.thr, open(self.a.thresholds, "w"), indent=2)
        dbm.set_control(self.con, "thresholds", json.dumps(self.det.thr))
        print(f"Calibrated combined-rule thresholds on {len(sc['attack']):,} Benign flows -> {self.a.thresholds}")

    # ------------------------------------------------------------------ one window
    def process(self, b, frame):
        t0 = time.time()
        det, con = self.det, self.con
        W = det.prepare_window(frame)
        res = det.score_window(W)
        main = W["main"]; n_main = len(main)
        labels = frame[LABEL].values if LABEL in frame.columns else np.array([None] * len(frame))
        alert_idx = np.where(res["alert"])[0]                        # positions inside `main`
        names = [det.label_of(p, u) for p, u in zip(res["pred"], res["unknown"])]
        by_class = pd.Series([names[i] for i in alert_idx]).value_counts().to_dict() if len(alert_idx) else {}
        keep = alert_idx[np.argsort(-res["attack"][alert_idx])][:MAX_ALERTS_STORED]
        # explanations for the strongest alert of each predicted class first
        expl_rows = []
        for c in dict.fromkeys(names[i] for i in keep):
            expl_rows += [i for i in keep if names[i] == c][:1]
        expl_rows = expl_rows[:self.a.explain_per_window]
        explanations = {}
        for i in expl_rows:
            try:
                explanations[i] = det.explain(W, frame, int(main[i]), int(res["pred"][i]), steps=self.a.ig_steps)
            except Exception as e:                                  # an explanation must never stop detection
                explanations[i] = {"error": str(e)}
        latency_ms = (time.time() - t0) * 1000
        rows_t = torch.tensor(main, device=det.device)
        tok_all, dt_all, pad_all = det.tokens(W, res["emb"], rows_t)
        v = det.version
        for i in keep:
            r = frame.iloc[main[i]]
            fam = family(names[i])
            cur = con.execute(
                "INSERT INTO alerts(window, ts, src, dst, sport, dport, proto, pred, family, confidence, attack_score, energy, msp,"
                " unknown, severity, true_label, explanation, model_version) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (b, str(r["_ts"]), r[SRC_IP], r[DST_IP], int(pd.to_numeric(r.get(SRC_PORT, 0), errors="coerce") or 0),
                 int(pd.to_numeric(r.get(DST_PORT, 0), errors="coerce") or 0), int(pd.to_numeric(r.get(PROTO, 0), errors="coerce") or 0),
                 names[i], fam, float(res["prob"][i].max()), float(res["attack"][i]), float(res["energy"][i]), float(res["msp"][i]),
                 int(res["unknown"][i]), SEVERITY.get(fam, "high"), labels[main[i]], json.dumps(explanations.get(i)) if i in explanations else None, v))
            self.tokens[f"a{cur.lastrowid}"] = (tok_all[i].half().cpu(), dt_all[i].cpu(), pad_all[i].cpu())
        rev = self.rng.choice(n_main, min(REVIEW_PER_WINDOW, n_main), replace=False)
        for i in rev:
            r = frame.iloc[main[i]]
            cur = con.execute("INSERT INTO reviews(window, ts, src, dst, pred, attack_score, alerted, true_label) VALUES(?,?,?,?,?,?,?,?)",
                              (b, str(r["_ts"]), r[SRC_IP], r[DST_IP], names[i], float(res["attack"][i]), int(res["alert"][i]), labels[main[i]]))
            self.tokens[f"r{cur.lastrowid}"] = (tok_all[i].half().cpu(), dt_all[i].cpu(), pad_all[i].cpu())
        true_attacks = int((labels[main] != "Benign").sum()) if labels[0] is not None else None
        con.execute("INSERT OR REPLACE INTO windows(id, start, flows, main_flows, hosts, alerts, unknown_alerts, alerts_by_class,"
                    " true_attacks, latency_ms, model_version, est_far, graph_json, processed_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (b, str(frame["_ts"][frame["_main"]].iloc[0].floor(f"{det.window_min}min")), len(frame), n_main,
                     len(W["g"]["hosts"]), int(len(alert_idx)), int(res["unknown"].sum()), json.dumps(by_class), true_attacks,
                     latency_ms, v, None, graph_snapshot(frame, main[alert_idx]), now()))
        con.commit()
        if self.a.auto_feedback is not None and labels[0] is not None:
            self.simulate_analyst(b)
        con.execute("UPDATE windows SET est_far=? WHERE id=?", (self.estimated_far(), b)); con.commit()
        return latency_ms, len(alert_idx), n_main

    def simulate_analyst(self, b):
        con = self.con
        con.execute("UPDATE reviews SET analyst_label=true_label WHERE window=? AND analyst_label IS NULL", (b,))
        ids = [r[0] for r in con.execute("SELECT id FROM alerts WHERE window=? AND status='new'", (b,))]
        for i in self.rng.choice(ids, int(len(ids) * self.a.auto_feedback), replace=False) if ids else []:
            con.execute("UPDATE alerts SET analyst_label=true_label, status=CASE WHEN true_label='Benign' THEN 'false_positive'"
                        " ELSE 'confirmed' END WHERE id=?", (int(i),))
        con.commit()

    def estimated_far(self, last_windows=10):
        r = pd.read_sql("SELECT alerted, analyst_label FROM reviews WHERE analyst_label IS NOT NULL AND window IN "
                        "(SELECT id FROM windows ORDER BY id DESC LIMIT ?)", self.con, params=(last_windows,))
        ben = r[r.analyst_label == "Benign"]
        return float(ben.alerted.mean()) if len(ben) >= 30 else None

    # ------------------------------------------------------------------ Champion / Challenger
    def feedback(self):
        a = pd.read_sql("SELECT 'a'||id AS key, analyst_label AS label FROM alerts WHERE analyst_label IS NOT NULL", self.con)
        r = pd.read_sql("SELECT 'r'||id AS key, analyst_label AS label FROM reviews WHERE analyst_label IS NOT NULL", self.con)
        fb = pd.concat([a, r]); fb = fb[fb.key.isin(self.tokens) & fb.label.isin(self.det.classes)]
        return fb

    def evaluate(self, model, keys, y):
        det = self.det
        with torch.no_grad():
            tok = torch.stack([self.tokens[k][0] for k in keys]).float().to(det.device)
            dt = torch.stack([self.tokens[k][1] for k in keys]).to(det.device)
            pad = torch.stack([self.tokens[k][2] for k in keys]).to(det.device)
            p = torch.softmax(model.from_tokens(tok, dt, pad) / det.T, 1).cpu().numpy()
        att = 1 - p[:, det.benign]; is_att = y != det.benign; fire = att > det.thr["attack"]
        far = float(fire[~is_att].mean()) if (~is_att).any() else 0.0
        dr = float(fire[is_att].mean()) if is_att.any() else 1.0
        return far, dr, float((p.argmax(1) == y).mean())

    def champion_challenger(self, b, reason):
        det, con = self.det, self.con
        fb = self.feedback()
        if len(fb) < MIN_FEEDBACK:
            return
        y = np.array([det.classes.index(l) for l in fb.label]); keys = fb.key.values
        perm = self.rng.permutation(len(keys)); cut = int(0.7 * len(keys))
        tr, ho = perm[:cut], perm[cut:]
        chal = copy.deepcopy(det.two); chal.train()
        opt = torch.optim.AdamW(chal.parameters(), lr=FT_LR, weight_decay=1e-4)
        tok = torch.stack([self.tokens[k][0] for k in keys]).float().to(det.device)
        dt = torch.stack([self.tokens[k][1] for k in keys]).to(det.device)
        pad = torch.stack([self.tokens[k][2] for k in keys]).to(det.device)
        yt = torch.tensor(y, device=det.device)
        for _ in range(FT_EPOCHS):
            order = tr[self.rng.permutation(len(tr))]
            for s in range(0, len(order), 128):
                i = torch.tensor(order[s:s + 128], device=det.device)
                loss = F.cross_entropy(chal.from_tokens(tok[i], dt[i], pad[i]), yt[i])
                opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(chal.parameters(), 1.0); opt.step()
        chal.eval()
        c_far, c_dr, c_acc = self.evaluate(det.two, keys[ho], y[ho])
        n_far, n_dr, n_acc = self.evaluate(chal, keys[ho], y[ho])
        accept = (n_far <= max(TARGET_FAR, c_far) + 1e-9) and (n_dr >= c_dr - 1e-9) and (n_acc >= c_acc)
        if accept:
            det.two = chal; det.version += 1
            torch.save(chal.state_dict(), self.versions_dir / f"two_stage_v{det.version}.pt")
            dbm.set_control(con, "model_version", det.version)
        con.execute("INSERT INTO model_events(time, window, event, n_feedback, champion_far, challenger_far, champion_dr, challenger_dr,"
                    " champion_acc, challenger_acc, accepted, version, note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (now(), b, "challenger promoted" if accept else "challenger rejected", len(fb), c_far, n_far, c_dr, n_dr,
                     c_acc, n_acc, int(accept), det.version, reason))
        con.commit()
        print(f"  [window {b}] challenger {'PROMOTED' if accept else 'rejected'} ({reason}) | held-out FAR {c_far:.3f}->{n_far:.3f}"
              f" DR {c_dr:.3f}->{n_dr:.3f} acc {c_acc:.3f}->{n_acc:.3f} | feedback {len(fb)}")

    def adapt_check(self, b, n_done):
        requested = dbm.get_control(self.con, "retrain_requested") == "1"
        if not requested and n_done % ADAPT_EVERY:
            return
        reasons = []
        far = self.estimated_far()
        if far is not None and far > TARGET_FAR * 1.5: reasons.append(f"estimated FAR {far:.3f}")
        missed = self.con.execute("SELECT COUNT(*) FROM reviews WHERE analyst_label IS NOT NULL AND analyst_label!='Benign'"
                                  " AND alerted=0 AND window > ?", (b - ADAPT_EVERY,)).fetchone()[0]
        if missed: reasons.append(f"{missed} missed attacks in review")
        fp = self.con.execute("SELECT COUNT(*) FROM alerts WHERE status='false_positive' AND window > ?", (b - ADAPT_EVERY,)).fetchone()[0]
        if fp: reasons.append(f"{fp} false positives confirmed")
        if requested: reasons.append("requested from dashboard"); dbm.set_control(self.con, "retrain_requested", "0")
        if reasons:
            self.champion_challenger(b, "; ".join(reasons))

    # ------------------------------------------------------------------ main loop
    def run(self):
        det = self.det
        print("Loading flows ...")
        df = load_flows(self.a.csv, det.features)
        wms, margin = det.window_min * 60_000, det.margin_sec * 1000
        wf = Path(str(self.a.csv) + ".windows.json")          # written by make_demo_csv.py: windows to replay
        only = set(json.load(open(wf))) if wf.exists() else None
        frames = list(windows_of(df, wms, margin, only))
        print(f"{len(df):,} flows -> {len(frames)} windows of {det.window_min} min")
        if self.a.calibrate_windows and not det.thr.get("calibrated") and LABEL in df.columns:
            self.calibrate(frames[: self.a.calibrate_windows])
        dbm.set_control(self.con, "status", "running")
        dbm.set_control(self.con, "total_windows", len(frames))
        for n, (b, frame) in enumerate(frames, 1):
            while dbm.get_control(self.con, "paused") == "1":
                time.sleep(1)
            lat, na, nm = self.process(b, frame)
            print(f"window {n}/{len(frames)} ({frame['_ts'].iloc[-1]:%Y-%m-%d %H:%M})  flows {nm:6d}  alerts {na:6d}  {lat:7.0f} ms")
            self.adapt_check(b, n)
            if self.a.sleep:
                time.sleep(self.a.sleep)
        dbm.set_control(self.con, "status", "finished")
        print("Replay finished.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--pkg", required=True, help="folder with final_model_package.pt + final_preprocessing.joblib")
    ap.add_argument("--csv", required=True, help="NetFlow-v3 CSV to replay (e.g. made by make_demo_csv.py)")
    ap.add_argument("--db", default="ids.db")
    ap.add_argument("--thresholds", default="thresholds.json")
    ap.add_argument("--calibrate-windows", type=int, default=0)
    ap.add_argument("--auto-feedback", type=float, default=None)
    ap.add_argument("--sleep", type=float, default=0.0, help="seconds to wait between windows (live feel)")
    ap.add_argument("--reset", action="store_true", help="clear the database first")
    ap.add_argument("--explain-per-window", type=int, default=EXPLAIN_PER_WINDOW, help="alerts explained per window (0 = off)")
    ap.add_argument("--ig-steps", type=int, default=8, help="Integrated-Gradients steps per explanation")
    Engine(ap.parse_args()).run()
